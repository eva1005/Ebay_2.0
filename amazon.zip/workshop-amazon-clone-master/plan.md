DAY 2
---------------------
Part 1: Create a Cart Page DONE
Part 2: Add items to Cart
Part 3: Style the Cart Page
Part 4: Enable deleting of item from Cart
Part 5: Enable changing quantiy of a cart
Part 6: DEPLOY
Part 7: LOGIN



DAY 1
------------------

Part 1: Implemented  the Header
Part 2: Create Cart Page
Part 3: Link Cart page when you click on cart
Part 4: Create banner
Part 5: Create Products
Part 6: Create Firebase 
Part 7: Connect Firebase with React


Homework:
1. Do the project to the current position
2. REplace second row with products database
3. Add trending component from Amazon